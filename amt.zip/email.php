<?php
// Get form data
$to = $_POST['to'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Set headers
$headers = "From: send2aqeelahmed@gmail.com\r\n";
$headers .= "Reply-To: VSmida@amtstaffing.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: multipart/mixed; boundary=\"boundary1\"\r\n";

// Check if attachment is uploaded
if(isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $filename = $_FILES['attachment']['name'];
    $file_tmp = $_FILES['attachment']['tmp_name'];
    $file_type = $_FILES['attachment']['type'];
    $file_size = $_FILES['attachment']['size'];
    $file_data = file_get_contents($file_tmp);

    // Encode file data and create attachment
    $file_data_encoded = base64_encode($file_data);
    $attachment = "--boundary1\r\n";
    $attachment .= "Content-Type: ".$file_type."; name=\"".$filename."\"\r\n";
    $attachment .= "Content-Transfer-Encoding: base64\r\n";
    $attachment .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
    $attachment .= $file_data_encoded."\r\n\r\n";
}

// Create message body
$message_body = "--boundary1\r\n";
$message_body .= "Content-Type: text/plain; charset=UTF-8\r\n";
$message_body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
$message_body .= $message."\r\n\r\n";

// Add attachment to message body
if(isset($attachment)) {
    $message_body .= $attachment;
}

// Send email
if(mail($to, $subject, $message_body, $headers)) {
    echo "Email sent successfully";
} else {
    echo "Error: Email not sent";
}
?>
